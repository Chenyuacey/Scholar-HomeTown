from django.apps import AppConfig


class SubmissionConfig(AppConfig):
    name = 'submission'
