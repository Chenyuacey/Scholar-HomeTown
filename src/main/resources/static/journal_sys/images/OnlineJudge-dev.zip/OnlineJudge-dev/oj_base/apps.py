from django.apps import AppConfig


class OjBaseConfig(AppConfig):
    name = 'oj_base'
