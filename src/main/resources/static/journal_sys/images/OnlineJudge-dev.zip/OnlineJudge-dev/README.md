# OnlineJudge
Simple Online Judge for Data Base curriculum design

# requirement
python==3.6.6  

django==2.1.1

bootstrap