from django.apps import AppConfig


class ProblemConfig(AppConfig):
    name = 'problem'
